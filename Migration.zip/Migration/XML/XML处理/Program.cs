﻿using System;
using System.IO;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace XML处理
{
    class Program
    {
        static void Main(string[] args)
        {
            //sample.xml
            //foreach (XmlNode node in nodeList)
            //{
            //    if (node.InnerText == "import") 
            //    {
            //       
            //        Str[i] = N0DE.ParentNode.FirstChild.InnerXml;
            //    }
            //    var currentNode = node.NextSibling; 
            //    while (currentNode != null)
            //    {
            //        currentNode = currentNode.NextSibling;
            //    }
            //}
            Func<string, string> ConvertGB = (t) =>
            {
                System.Text.Encoding utf8, gb2312;
                gb2312 = System.Text.Encoding.Default;
                utf8 = System.Text.Encoding.GetEncoding("utf-8");
                byte[] gb;
                gb = gb2312.GetBytes(t);
                gb = System.Text.Encoding.Convert(gb2312, utf8, gb);
                return utf8.GetString(gb);
            };

            string org_path = ConfigurationManager.AppSettings["org"].ToString();
            string[] fileArray = Directory.GetFiles(org_path, "*.txt");
            for (int i = 0; i < fileArray.Length; i++)
            {
                string[] Str = new string[3];
                XmlDocument doc = new XmlDocument();
                doc.Load(fileArray[i]);
                Console.WriteLine(string.Format("Load the file : {0}", fileArray[i]));
                XmlNodeList nodeList = doc.SelectSingleNode("import").ChildNodes;
                foreach (XmlNode node in nodeList)
                {
                    XmlElement xe = (XmlElement)node;
                    if (xe.GetAttribute("type") == "document")
                    {
                        XmlNodeList nls = xe.ChildNodes;
                        foreach (XmlNode xn1 in nls)
                        {
                            XmlElement xe2 = (XmlElement)xn1;
                            if (xe2.Name == "location") { Str[0] = xe2.InnerText; }
                            if (xe2.Name == "file") { Str[2] = xe2.InnerText; }
                            if (xe2.Name == "title" && xe2.GetAttribute("language") == "en_US")
                            {
                                string[] Cs = Str[0].Split(':');
                                if (Cs.Count() > 2)
                                {

                                    Str[1] = xe2.InnerText;
                                    //string filename = ConvertGB(Str[1]);
                                    string filename = Str[1];
                                    //string filename = "SVC2018_南京光明_Claim_001.pdf";
                                    //string path = AppDomain.CurrentDomain.BaseDirectory.ToString()+Cs[2]+"\\"+Str[1];
                                    //string path = AppDomain.CurrentDomain.BaseDirectory.ToString()+Cs[2]+"\\"+ Cs[3];
                                    string path = ConfigurationManager.AppSettings["dest"].ToString() ;
                                    for (int j = 2; j < Cs.Length; j++) {
                                        path += "\\";
                                        path += Cs[j];
                                        Console.WriteLine(string.Format("Create a folder {0}", Cs[j]));
                                        if (!Directory.Exists(path))
                                        {
                                            Directory.CreateDirectory(path);
                                        }
                                    };
                                    Console.WriteLine(string.Format("Copy file {0} change name to{1}", Str[2], filename));
                                    try
                                    {

                                        File.Copy(Str[Str.Length-1], path + "\\" + filename, true);
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine(string.Format("文件拷贝出错，错误信息为:{0}", ex.ToString()));
                                    }
                                }
                            }
                        }
                        //break;
                    }
                }



            };

            // Console.ReadKey();
            Console.WriteLine("It is done!");
        }
    }
}
